# Dubai Property Pulse: Power BI project

A Power BI report on synthetic Dubai residential sales: a market overview, a page to compare communities by any metric, and an AI insights page.

## Open it

1. Right-click the zip and choose **Extract all**. Opening the .pbip from inside the zip will not work.
2. In the extracted folder, double-click `Dubai Property Pulse.pbip`.
3. Click **Refresh now** on the yellow bar (or **Home > Refresh**) to load the data. It is embedded in the file, so no other files are needed.
4. To get a single `.pbix`, use **File > Save as** and choose `.pbix`.

## Pages

- **Market overview:** auto-written headline, five KPI cards, sales by month, price per sq ft by community, off-plan trend.
- **Compare communities:** pick a metric (sales value, transactions, price per sq ft, yield, off-plan share) and the ranking re-sorts; buyer origin; community scorecard.
- **AI insights:** decomposition tree on sales value.

In Power BI Desktop, hold **Ctrl** and click the sidebar links to move between pages. In the Power BI service a normal click works.

## Check it loaded correctly

With no filters selected you should see:

- Sales value about AED 10.79bn, 3,093 transactions, AED 2,199 per sq ft, 57% off-plan, 6.3% average gross yield
- Headline: "Dubai South pays the most rent for the price at a 7.6% gross yield, 3.1 points above Palm Jumeirah."
- Summary mentions sales up 31% on the year before (latest 12 months against the 12 before)

If a visual shows "Something's wrong with one or more fields", or Power BI shows an error, send a screenshot so it can be fixed.

## About the AI insights page

The decomposition tree is one of Power BI's built-in AI visuals. Click **+** on any bar to split the number by another field, or choose **High value** and Power BI picks the split that explains the most. If this visual ever shows a field error, select it and drag the main measure into **Analyze** and the dimension columns into **Explain by**.

Every table, column and measure has a description, so the model is ready for Copilot and **Prep data for AI** if your organisation has a Fabric capacity that runs Copilot.

All figures are synthetic and are not real company or government data.
