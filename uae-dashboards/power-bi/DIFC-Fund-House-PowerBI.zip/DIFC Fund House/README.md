# DIFC Fund House: Power BI project

A two-page Power BI report on the synthetic DIFC fund house data: an executive overview, and a clients and liquidity page. It has a navy sidebar with page navigation and filters, icon KPI cards, a headline that writes itself from the data, and a star-schema model with 23 DAX measures. The data is embedded in the queries, so it needs no files or database.

## Open it

1. Right-click the zip and choose **Extract all**. Opening the .pbip from inside the zip will not work, because Power BI needs the two folders next to it.
2. In the extracted folder, double-click `DIFC Fund House.pbip`. If Power BI Desktop refuses the file type, turn on **File > Options and settings > Options > Preview features > Power BI Project (.pbip) save option**, restart, and try again.
3. Click **Home > Refresh** to load the data.
4. To get a single `.pbix` file, use **File > Save as** and choose the `.pbix` type.

With no filters selected you should see:

- Total assets about $5.29bn, net flows about $724M, return 42.3%, 1.7 points ahead of the benchmark, and 76% payable within 7 days
- Headline: "Private Credit beat its benchmark by 8.1 points, while Global Equity fell short by 4.8 points."
- Clients page: 140 active clients, 20 cutting holdings by more than 20%, about $314M withdrawn

If Power BI shows an error, take a screenshot of the message and send it back so it can be fixed.

## How the design works

The sidebar, card frames, icons and chart titles are two background images (`bg-overview.png` and `bg-clients.png` in `StaticResources/RegisteredResources`), set as each page's canvas background. The live visuals sit on top with transparent backgrounds, which is how most polished Power BI reports are built.

- The sidebar page links are buttons. In Power BI Desktop, hold **Ctrl** and click them; in the Power BI service a normal click works.
- If you move a visual, keep it within its card frame, since the frames are part of the image.
- To change a chart title, edit the background image, or switch the visual's own title on under **Format > General > Title**.

## What's in the model

| Table | Role | Rows |
|---|---|---|
| Fund Monthly | Fact: month-end assets, flows and returns per fund (US$ millions) | 165 |
| Clients | Fact: each client's holding in Sep 2025 and Sep 2026 | 146 |
| Funds | Dimension: one row per fund | 5 |
| Liquidity | Share of each fund payable in each dealing bucket | 25 |
| Calendar | Month-level dimension, Jan 2024 to Sep 2026 | 33 |

Three measures worth knowing well for interviews:

- **Return** compounds asset-weighted monthly returns with `PRODUCTX`, so it stays correct for any period the filters pick.
- **Growth of 100** uses `ALLSELECTED ( 'Calendar' )` so the line starts at $100 at the beginning of whatever period is selected.
- **Headline** ranks funds by excess return with `TOPN` and writes the finding as a sentence that rewrites itself when the filters change.

## Put it on your website

1. Save as `.pbix` and upload it to `uae-dashboards/power-bi/` in your site's GitHub repository.
2. Take a real screenshot of each page in Power BI and save them as `uae-dashboards/power-bi/overview.png` and `uae-dashboards/power-bi/clients.png`. The Power BI page on your site shows them automatically.
3. Optional: if your account allows **File > Embed report > Publish to web**, paste the link into `const POWER_BI_EMBED_URL = "";` near the bottom of `power-bi.html`.

All figures are synthetic and are not real company data.
