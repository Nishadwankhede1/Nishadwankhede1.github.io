# Shelf and Sales: Power BI project

A Power BI report on synthetic sell-out data for a UAE FMCG distributor: a sales overview, a page to compare channels by any metric, and an AI insights page.

## Open it

1. Right-click the zip and choose **Extract all**. Opening the .pbip from inside the zip will not work.
2. In the extracted folder, double-click `Shelf and Sales.pbip`.
3. Click **Refresh now** on the yellow bar (or **Home > Refresh**) to load the data. It is embedded in the file, so no other files are needed.
4. To get a single `.pbix`, use **File > Save as** and choose `.pbix`.

## Pages

- **Sales overview:** auto-written headline, five KPI cards, net sales by month, net sales by channel, category mix.
- **Compare channels:** pick a metric (net sales, cases, margin, promo share, on-shelf availability); margin against promo share by channel; channel scorecard.
- **AI insights:** decomposition tree on net sales.

In Power BI Desktop, hold **Ctrl** and click the sidebar links to move between pages. In the Power BI service a normal click works.

## Check it loaded correctly

With no filters selected you should see:

- Net sales about AED 1,607.5M, 30,664,124 cases, 25.6% gross margin, 29% promo share, 94.8% on-shelf availability
- Headline: "Online grocery is the fastest-growing channel, up 46% on the year before, while Hypermarket relies most on promotions, at 43% of sales."

If a visual shows "Something's wrong with one or more fields", or Power BI shows an error, send a screenshot so it can be fixed.

## About the AI insights page

The decomposition tree is one of Power BI's built-in AI visuals. Click **+** on any bar to split the number by another field, or choose **High value** and Power BI picks the split that explains the most. If this visual ever shows a field error, select it and drag the main measure into **Analyze** and the dimension columns into **Explain by**.

Every table, column and measure has a description, so the model is ready for Copilot and **Prep data for AI** if your organisation has a Fabric capacity that runs Copilot.

All figures are synthetic and are not real company or government data.
