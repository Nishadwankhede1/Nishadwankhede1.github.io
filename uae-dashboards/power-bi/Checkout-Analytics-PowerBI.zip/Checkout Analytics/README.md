# Checkout Analytics: Power BI project

A Power BI report on a synthetic UAE online store: a store overview, a page to compare emirates by any metric, and an AI insights page.

## Open it

1. Right-click the zip and choose **Extract all**. Opening the .pbip from inside the zip will not work.
2. In the extracted folder, double-click `Checkout Analytics.pbip`.
3. Click **Refresh now** on the yellow bar (or **Home > Refresh**) to load the data. It is embedded in the file, so no other files are needed.
4. To get a single `.pbix`, use **File > Save as** and choose `.pbix`.

## Pages

- **Store overview:** auto-written headline, five KPI cards, revenue by month, revenue by category, payment mix.
- **Compare emirates:** pick a metric (revenue, orders, return rate, cash on delivery, delivery time); cash-on-delivery vs prepaid returns by category; emirate scorecard.
- **AI insights:** decomposition tree on revenue.

In Power BI Desktop, hold **Ctrl** and click the sidebar links to move between pages. In the Power BI service a normal click works.

## Check it loaded correctly

With no filters selected you should see:

- Revenue about AED 207.8M, 682,331 orders, average order AED 304, return rate 8.0%, cash on delivery 24%
- Headline: "Cash-on-delivery orders are 24% of orders but 44% of returns: they come back 14.5% of the time, against 5.9% for prepaid."

If a visual shows "Something's wrong with one or more fields", or Power BI shows an error, send a screenshot so it can be fixed.

## About the AI insights page

The decomposition tree is one of Power BI's built-in AI visuals. Click **+** on any bar to split the number by another field, or choose **High value** and Power BI picks the split that explains the most. If this visual ever shows a field error, select it and drag the main measure into **Analyze** and the dimension columns into **Explain by**.

Every table, column and measure has a description, so the model is ready for Copilot and **Prep data for AI** if your organisation has a Fabric capacity that runs Copilot.

All figures are synthetic and are not real company or government data.
