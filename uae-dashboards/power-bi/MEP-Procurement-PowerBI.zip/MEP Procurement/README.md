# MEP Procurement: Power BI project

A four-page Power BI report for the procurement team of a UAE MEP (mechanical, electrical, plumbing) contractor, built on synthetic data: 2,321 purchase orders across eight projects, 26 suppliers and 24 items, January 2025 to October 2026.

| Page | What it answers |
|---|---|
| Executive overview | How much have we committed, what did negotiation save, are we paying above market, and are suppliers on time? |
| Spend and price | Where the money goes, how LV cable prices tracked LME copper, and which categories are over budget |
| Supplier performance | Who is late, who causes NCRs, who is expensive: a weighted supplier score with a recommended action |
| Process and compliance | PR-to-PO cycle time by buyer, maverick and single-source spend, and an AI decomposition tree |

It has a dark icon-rail design, page navigation buttons, Year / Project / Discipline slicers on every page, a headline and summary that rewrite themselves from the data, and a star-schema model with 48 DAX measures. The data is embedded in the queries, so it needs no files or database.

## Open it

1. Right-click the zip and choose **Extract all**. Opening the .pbip from inside the zip will not work, because Power BI needs the two folders next to it.
2. In the extracted folder, double-click `MEP Procurement.pbip`. If Power BI Desktop refuses the file type, turn on **File > Options and settings > Options > Preview features > Power BI Project (.pbip) save option**, restart, and try again.
3. Click **Home > Refresh** to load the data.
4. To get a single `.pbix` file, use **File > Save as** and choose the `.pbix` type.

With no filters selected you should see:

- Committed spend AED 810.8M, negotiated savings AED 31.6M (3.8%), price vs market +1.5%, on-time delivery 78.8%, on-contract spend 30.4%
- Headline: "Negotiation saved AED 31.6M (3.8%), but Chillers cost AED 10.7M above market. Weakest on delivery: Hanzhou HVAC Export Co at 53% on time."
- Supplier page: 26 suppliers, NCR rate 5.3%, first-pass invoice match 89.5%, 6 overdue open POs
- Process page: PR to PO 12.1 days, maverick spend 3.6%, single-source spend 12.9%

If Power BI shows an error, take a screenshot of the message and send it back so it can be fixed.

## The model

| Table | Role | Rows |
|---|---|---|
| Purchase Orders | Fact: one row per PO with PR / PO / need-by / delivery dates, quoted, budget, benchmark and final value, NCR and invoice-match flags | 2,321 |
| Suppliers | Dimension: type, country, origin (Local / GCC / Import), ICV certification | 26 |
| Items | Dimension: item, category, discipline, unit, copper-linked flag, lead time | 24 |
| Projects | Dimension: project, emirate, sector, MEP procurement budget | 8 |
| Calendar | Month-level dimension with the LME copper price | 22 |
| Metric | Disconnected table that drives the metric picker | 7 |

## Measures worth knowing for interviews

- **Negotiated savings** = quoted value minus PO value. **Savings %** divides by quoted value.
- **PPV** (purchase price variance) = PO value minus the market benchmark in the PO month. Copper-linked items (LV and MV cable, copper pipe) move with LME copper, so the report can separate market inflation from bad buying.
- **Variance to budget** prices ordered quantities at rates fixed when each project started, so copper inflation shows up as budget overrun even when we bought below market.
- **Spend PY** shifts the selected months back 12 using `TREATAS` on the month number, and **Spend YoY %** only compares months that have a prior-year month (like for like).
- **Cumulative spend %** builds the Pareto line with `ALLSELECTED` so it respects the slicers.
- **Supplier score** = 40% on-time delivery + 30% quality (1 − 5 × NCR rate) + 30% price (market rate = half marks). **Supplier action** turns it into Preferred / Improvement plan / Review contract.
- **Maverick spend %** = spend with no approved requisition before the PO.
- **Headline** uses `TOPN` over `ADDCOLUMNS` to find the category with the largest overpayment and the least reliable supplier (15+ deliveries), then writes the sentence.

## How the design works

The rail, card frames, icons and chart titles are background images (`bg-*.png` in `StaticResources/RegisteredResources`), set as each page's canvas background. The live visuals sit on top with transparent backgrounds.

- The rail page links are buttons. In Power BI Desktop, hold **Ctrl** and click them; in the Power BI service a normal click works.
- If you move a visual, keep it within its frame, since the frames are part of the image.

All figures are synthetic and are not real company data. Project and supplier names are fictional.
